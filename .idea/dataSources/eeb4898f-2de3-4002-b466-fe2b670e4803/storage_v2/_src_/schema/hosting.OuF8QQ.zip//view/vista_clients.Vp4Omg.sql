create definer = root@localhost view vista_clients as
select `c`.`nom`     AS `nom`,
       `c`.`cognoms` AS `cognoms`,
       `c`.`email`   AS `email`,
       `c`.`pais`    AS `pais`,
       `c`.`domini`  AS `domini`,
       `p`.`Preu`    AS `Preu`
from (`hosting`.`clients` `c`
       join `hosting`.`plans` `p` on ((`c`.`plaHosting` = `p`.`idPlan`)))
order by `c`.`plaHosting`;

