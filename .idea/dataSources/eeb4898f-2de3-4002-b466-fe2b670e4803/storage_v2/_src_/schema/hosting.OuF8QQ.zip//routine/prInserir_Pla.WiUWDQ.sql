create
  definer = root@localhost procedure prInserir_Pla(IN p_PlaHosting varchar(50), IN p_quota int, IN p_Preu int,
                                                   IN p_nWebs int, IN p_nEmails int, IN p_anchoBanda int,
                                                   IN p_basesDatos int, IN p_procesador varchar(100),
                                                   IN p_memoria varchar(100), IN p_sslIncluido int,
                                                   IN p_copiaSeguridad int, IN p_Webmail int, IN p_Subdominis int,
                                                   IN p_ComtesFTP int, IN p_Inodos int, IN p_accesSSH int,
                                                   IN p_Cronjobs int, IN p_compatibleWordPress int, IN p_soport int)
BEGIN
	insert into plans(PlaHosting, quota, Preu, nWebs, nEmails, anchoBanda, basesDatos, procesador, memoria, sslIncluido, copiaSeguridad, Webmail, Subdominis, ComtesFTP, Inodos, accesSSH, Cronjobs, compatibleWordPress, soport) 
    values (p_PlaHosting, p_quota, p_Preu, p_nWebs, p_nEmails, p_anchoBanda, p_basesDatos, p_procesador, p_memoria, p_sslIncluido, p_copiaSeguridad, p_Webmail, p_Subdominis, p_ComtesFTP, p_Inodos, p_accesSSH, p_Cronjobs, p_compatibleWordPress, p_soport);
END;

